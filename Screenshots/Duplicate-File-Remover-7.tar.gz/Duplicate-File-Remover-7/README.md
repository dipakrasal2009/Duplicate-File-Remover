# Duplicate-File-Remover

![Project Screenshot](https://github.com/dipakrasal2009/Duplicate-File-Remover/blob/main/Screenshots/1.png)
![Project Screenshot](https://github.com/dipakrasal2009/Duplicate-File-Remover/blob/main/Screenshots/2.png)
![Project Screenshot](https://github.com/dipakrasal2009/Duplicate-File-Remover/blob/main/Screenshots/3.png)
![Project Screenshot](https://github.com/dipakrasal2009/Duplicate-File-Remover/blob/main/Screenshots/4.png)
![Project Screenshot](https://github.com/dipakrasal2009/Duplicate-File-Remover/blob/main/Screenshots/5.png)
![Project Screenshot](https://github.com/dipakrasal2009/Duplicate-File-Remover/blob/main/Screenshots/6.png)
![Project Screenshot](https://github.com/dipakrasal2009/Duplicate-File-Remover/blob/main/Screenshots/7.png)

